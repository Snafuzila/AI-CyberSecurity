"""Phase 4: find one real NSL-KDD test event for each of the 4 agreement/disagreement
scenarios, run it through the Phase 2 payload generator and the Phase 3 orchestrator,
and print the resulting LLM prompts side-by-side (IF vs AE) for each scenario. No LLM
is actually called -- this prints what would be sent to one."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from config import RunConfig
from data_pipeline import load_nsl_kdd
from enriched_payload import generate_enriched_payload, load_artifacts
from llm_orchestrator import build_llm_prompt, rai_policy_evaluator

LAB_ROOT = Path(__file__).resolve().parents[2]

SCENARIOS = {
    "A: Both Alert (agreement on anomaly)": lambda ifp, aep: (ifp == 1) & (aep == 1),
    "B: Isolation Forest ONLY (disagreement)": lambda ifp, aep: (ifp == 1) & (aep == 0),
    "C: Autoencoder ONLY (disagreement)": lambda ifp, aep: (ifp == 0) & (aep == 1),
    "D: Both Normal (agreement on benign)": lambda ifp, aep: (ifp == 0) & (aep == 0),
}


def _score_all(artifacts, X_test: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    if_scores = -artifacts.if_model.decision_function(X_test)
    with torch.no_grad():
        x_t = torch.tensor(X_test, dtype=torch.float32)
        ae_scores = torch.mean((artifacts.ae_net(x_t) - x_t) ** 2, dim=1).numpy()
    return if_scores, ae_scores


def main() -> None:
    cfg = RunConfig(nsl_kdd_dir=LAB_ROOT / "data")
    dataset = load_nsl_kdd(cfg)
    artifacts = load_artifacts()
    thresholds = artifacts.manifest["thresholds"]

    if_scores, ae_scores = _score_all(artifacts, dataset.X_test)
    if_pred = (if_scores >= thresholds["Isolation_Forest"]).astype(int)
    ae_pred = (ae_scores >= thresholds["Autoencoder"]).astype(int)

    for label, mask_fn in SCENARIOS.items():
        matches = np.where(mask_fn(if_pred, ae_pred))[0]
        print("\n" + "=" * 100)
        print(label)
        print("=" * 100)
        if len(matches) == 0:
            print("No test event matches this scenario.")
            continue

        idx = int(matches[0])
        event = dataset.test_raw.iloc[idx]
        event_id = f"scenario-{label[0]}-idx{idx}"
        if_payload, ae_payload = generate_enriched_payload(event, event_id)

        for payload in (if_payload, ae_payload):
            decision = rai_policy_evaluator(payload)
            print(f"\n--- {payload['triggering_model']} prompt (predicted_class={payload['predicted_class']}) ---")
            print(build_llm_prompt(payload, decision))


if __name__ == "__main__":
    main()
